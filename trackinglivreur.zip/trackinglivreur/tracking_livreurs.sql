-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 03 avr. 2023 à 02:49
-- Version du serveur : 10.4.27-MariaDB
-- Version de PHP : 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `tracking_livreurs`
--

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `id_commande` int(15) NOT NULL,
  `date_debut` varchar(15) NOT NULL,
  `date_fin` varchar(15) NOT NULL,
  `etat` varchar(15) DEFAULT NULL,
  `distance_Km` double NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `id_livreur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`id_commande`, `date_debut`, `date_fin`, `etat`, `distance_Km`, `adresse`, `id_livreur`) VALUES
(1, '12/03/2023', '14/03/2023', 'LIVRÉ', 250, 'TANGER,MAROC', 2),
(7, '10/10/2020', '11/11/2020', 'Refusé', 1000, 'OUJDA', 1),
(9, '03/04/2023', '04/04/2023', 'En cours', 150, 'RABAT', 9),
(11, '22/12/2021', '25/12/2021', 'livré', 40, 'Bouznika', 19),
(12, '22/12/2022', '25/01/2021', 'Refusé', 250, 'Fes,Maroc', 11);

-- --------------------------------------------------------

--
-- Structure de la table `livreur`
--

CREATE TABLE `livreur` (
  `id_livreur` int(11) NOT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `livreur`
--

INSERT INTO `livreur` (`id_livreur`, `nom`, `telephone`) VALUES
(1, 'liv1', '000000000'),
(2, 'liv3', '200000000'),
(3, 'liv2', '100000000'),
(4, 'liv4', '9890890890808'),
(5, 'test', '00009'),
(6, 'yoyo', '48589479545'),
(7, 'Ahmad', '348594385748'),
(8, 'yyyy', '4545'),
(9, 'zzzz', '09009090909'),
(10, 'siham alami', '42536778'),
(11, 'ossama', '4253698'),
(12, 'salma', '123456'),
(13, 'amine', '12345678'),
(16, 'mohammed alami', '068876408'),
(19, 'siham yamlahi alami', '0612321234'),
(20, 'ilyass', '0654487886');

-- --------------------------------------------------------

--
-- Structure de la table `login`
--

CREATE TABLE `login` (
  `code` int(11) NOT NULL,
  `nom` varchar(40) NOT NULL DEFAULT '',
  `mdp` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `login`
--

INSERT INTO `login` (`code`, `nom`, `mdp`) VALUES
(1, 'admin', 'admin@2002');

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE `produit` (
  `id_produit` int(15) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prix` int(20) NOT NULL,
  `quantite` int(15) NOT NULL,
  `id_commande` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`id_produit`, `nom`, `prix`, `quantite`, `id_commande`) VALUES
(5, 'Pontalon', 250, 2, 1),
(7, 'cartable', 250, 3, 7),
(9, 'Lunette', 350, 2, 1);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`id_commande`),
  ADD KEY `id_livreur` (`id_livreur`);

--
-- Index pour la table `livreur`
--
ALTER TABLE `livreur`
  ADD PRIMARY KEY (`id_livreur`);

--
-- Index pour la table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`code`) USING BTREE COMMENT 'ADM';

--
-- Index pour la table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`id_produit`),
  ADD KEY `id_commande` (`id_commande`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `commande`
--
ALTER TABLE `commande`
  MODIFY `id_commande` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `livreur`
--
ALTER TABLE `livreur`
  MODIFY `id_livreur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT pour la table `login`
--
ALTER TABLE `login`
  MODIFY `code` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `produit`
--
ALTER TABLE `produit`
  MODIFY `id_produit` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`id_livreur`) REFERENCES `livreur` (`id_livreur`);

--
-- Contraintes pour la table `produit`
--
ALTER TABLE `produit`
  ADD CONSTRAINT `produit_ibfk_1` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
